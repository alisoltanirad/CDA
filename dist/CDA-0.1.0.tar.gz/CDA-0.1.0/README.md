# University Data Analysis

Data analysis of US colleges and universities.
Data source: College Scorecard.